#
# ~/.bashrc
#

########
# Bash #
########

# If not running interactively, don't do anything
[[ $- != *i* ]] && return

PS1='[\W]\$ '

set -o vi

# foot maps Ctrl+1 to this private sequence.
bind -m vi-insert '"\e[9001~": vi-edit-and-execute-command'
bind -m vi-command '"\e[9001~": vi-edit-and-execute-command'

###########
# Aliases #
###########

# general
alias ..='cd ..'
alias grep='grep --color=auto'
alias l='eza -l -a --time-style=long-iso --sort=name --group-directories-first --icons --git'
alias ll='eza -l -a --time-style=long-iso --sort=name --group-directories-first --icons --git'
alias v='nvim'
alias a='codex'
alias f='yazi'
alias x='clear'

# git
g() {
  if [[ $# -eq 0 ]]; then
    git
    return
  fi

  local cmd="$1"
  shift

  case "$cmd" in
    s)  git status ;;
    b)  git branch -a ;;
    l)  git log --oneline ;;
    L)  git log ;;
    d)  git diff ;;
    D)  git diff --staged ;;
    p)  git pull ;;
    a)  git add . ;;
    u)  git commit -m "update" ;;
    c)
      if [[ $# -ne 1 ]]; then
        echo 'Usage: g c "commit message"' >&2
        return 1
      fi
      git commit -m "$1"
      ;;
    P)  git push ;;
    *)  git "$cmd" "$@" ;;
  esac
}

############
# Programs #
############

# zoxide
command -v zoxide >/dev/null && eval "$(zoxide init --cmd c bash)"

# eza
export EXA_COLORS="da=2:uu=2:"

# fzf: In case Ctrl-R doesn't work well
[ ! -r /usr/share/doc/fzf/examples/key-bindings.bash ] || source /usr/share/doc/fzf/examples/key-bindings.bash
[ ! -r /usr/share/doc/fzf/examples/completion.bash ] || source /usr/share/doc/fzf/examples/completion.bash

# nvim
export EDITOR=nvim
export VISUAL=nvim

# opencode
[ ! -d "$HOME/.opencode/bin" ] || export PATH="$HOME/.opencode/bin:$PATH"

#########
# Other #
#########

# >>> Codex installer >>>
export PATH="/home/pateplay/.local/bin:$PATH"
# <<< Codex installer <<<
